The driver package files in this folder can be used to install drivers for Intel(R) Ethernet 40GbE Adapters and Connections on the following Operating Systems:
   *  Microsoft* Windows Server* 2019 (x64 Edition)
   
The driver package supports devices based on the following controllers:
  * Intel(R) Ethernet Controller X710
  * Intel(R) Ethernet Controller XL710
  * Intel(R) Ethernet Network Connection X722
  * Intel(R) Ethernet Controller XXV710
