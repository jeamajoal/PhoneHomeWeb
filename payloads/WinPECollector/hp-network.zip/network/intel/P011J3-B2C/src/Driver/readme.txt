The driver package files in this folder can be used to install drivers for Intel(R) Ethernet 2.5 Gigabit Adapters and Connections on the following operating systems:
  *  Microsoft* Windows* 10 Version 1809 (x64 Edition)
  *  Microsoft Windows Server* 2019 (x64 Edition)
   
The driver package supports devices based on the following controllers:
  * Intel(R) Ethernet Controller I225
